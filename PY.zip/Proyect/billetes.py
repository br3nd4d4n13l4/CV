b_20 = int(input("billetes de 20$: "))
b_50 = int(input("billetes de 50$: "))
b_100 = int(input("billetes de 100$: "))
b_200 = int(input("billetes de 200$: "))
b_500 = int(input("billetes de 500$: "))

total = (b_20 * 20) + (b_50 * 50) + (b_100 * 100) + (b_200 * 200) + (b_500 * 500)

print(total)